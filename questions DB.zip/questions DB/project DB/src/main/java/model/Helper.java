package model;

public class Helper {
    public sqlConnection sql = new sqlConnection();
    public static boolean fromDB = false;

}
