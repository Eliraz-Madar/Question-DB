Hello,
This program desgined to maintain a database fore question.
this program can creat from the DB an exam from the question that are in the database.

To run this program pleas cange all ste relevant sql propeties.
Run the joined sqlFile to creat the first databas.
Then run the javaFX program and controll the DB from the GUI.